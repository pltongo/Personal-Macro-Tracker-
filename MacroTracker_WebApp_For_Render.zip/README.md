# MacroTracker Pro - Full-Stack Web Application

A modern, responsive, zero-dependency full-stack web application designed for personal nutrition tracking. Built specifically for cross-platform use (mobile phone and desktop browser) with full single-user customization.

## Key Features

1. **Dual-Platform Responsive Design**:
   - **Mobile Experience**: Touch-optimized interface, camera capture (`capture="environment"`), quick-action buttons, bottom navigation.
   - **Desktop Experience**: Wide-screen dashboard with live macro progress rings, side-by-side meal breakdowns, and trend analytics.

2. **Daily Fresh Tracker**:
   - Automatically initializes a fresh log for each new calendar day.
   - Fast date navigation (Today, Prev/Next day, or any custom date via date picker).
   - Categorizes meals into **Breakfast**, **Lunch**, **Dinner**, and **Snacks**.

3. **Multimodal Meal Logging (Images & Descriptions)**:
   - **Photo / Camera**: Snap a picture of your plate or food packaging; preview and store images alongside nutritional data.
   - **Text Description**: Input plain English food descriptions (e.g., *"8oz chicken breast, 1.5 cups jasmine rice, 1 cup steamed broccoli, 1 tbsp olive oil"*).
   - **Smart Nutrition Estimation**: Automatically parses food items and weights, calculating instant estimates for:
     - Calories (kcal)
     - Protein (g)
     - Carbohydrates (g)
     - Total Fat (g)
     - Sodium (mg)
     - Dietary Fiber (g)
   - **Editable Before Saving**: Every estimate can be fine-tuned or manually overridden before saving to your daily log.

4. **End-of-Week Averages & Trend Analytics**:
   - Automatically computes 7-day averages for protein, carbohydrates, fats, sodium, calories, and fiber.
   - Compares weekly averages directly against your custom daily targets.
   - Visual bar chart displaying daily protein intake throughout the week.
   - Complete tabular breakdown of every individual day in the week.

5. **Full Personal Customization**:
   - Set custom daily targets for calories, protein, carbs, fat, sodium, and fiber.
   - Configure week start day (Monday vs. Sunday).
   - Light / Dark theme toggle.
   - One-click data export to **CSV spreadsheet** or **JSON backup**.

---

## Quick Start (Run Locally)

The application has **zero external package dependencies** and runs on any computer with Python 3.8+:

```bash
# 1. Navigate to the project directory
cd macro_tracker_app

# 2. Start the web server
python3 app.py
```

Open your browser to:
**`http://localhost:8000`**

### Accessing from Your Mobile Phone on the Same Wi-Fi
To use the app on your phone while running it on your laptop/desktop:
1. Find your computer's local IP address (e.g., `192.168.1.50`).
   - On macOS/Linux: `ipconfig getifaddr en0` or `hostname -I`
   - On Windows: `ipconfig` (IPv4 Address)
2. Open your phone's browser (Safari or Chrome) and navigate to:
   `http://<YOUR_COMPUTER_IP>:8000`
3. **Add to Home Screen**:
   - On iOS (Safari): Tap the **Share** button -> **Add to Home Screen**.
   - On Android (Chrome): Tap the **Menu** (three dots) -> **Add to Home screen** / **Install app**.
   - It will now open as a standalone fullscreen app on your phone!

---

## Free Cloud Deployment Options

If you want the app accessible from anywhere on the internet without running your computer:

### Option A: Render (Free Web Service)
1. Push this folder to a GitHub repository.
2. In Render, create a **New Web Service** pointing to your repository.
3. Set the start command to: `python3 app.py`
4. Deploy! Render will give you a free live URL (e.g., `https://my-macro-tracker.onrender.com`).

### Option B: Docker
A `Dockerfile` is included:
```bash
docker build -t macro-tracker .
docker run -p 8000:8000 macro-tracker
```

---

## File Structure

```text
macro_tracker_app/
├── app.py                # Main server, REST API, SQLite DB, & nutrition estimator
├── static/
│   ├── index.html        # Responsive frontend layout (Mobile & Desktop)
│   ├── css/
│   │   └── style.css     # Clean theme styling (Dark/Light modes, zero CDN dependencies)
│   ├── js/
│   │   └── app.js        # Dynamic UI state, API calls, estimation, & analytics
│   └── uploads/          # Local storage directory for meal photos
├── Dockerfile            # Container deployment configuration
├── Procfile              # Cloud hosting process configuration
└── README.md             # Documentation and usage guide
```
